<?php
session_start();
error_reporting(0);
include('../includes/config.php'); // Updated path to config.php
if(strlen($_SESSION['alogin'])==0) { 
    header('location:index.php');
} else { 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | Admin Dashboard</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <!-- Vibrant Banner -->
            <div class="row">
                <div class="col-md-12">
                    <div style="background: linear-gradient(90deg, #ffecd2 0%, #fcb69f 100%); border-radius: 18px; box-shadow: 0 4px 24px rgba(252,182,159,0.12); margin-bottom: 32px; padding: 32px 0; text-align:center;">
                        <span style="color:#dd2476; font-size:2.2em; font-weight:bold; text-shadow:0 2px 12px #fcb69f; letter-spacing:2px;">Welcome, Admin!</span>
                    </div>
                </div>
            </div>
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">ADMIN DASHBOARD</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-6">
                    <div class="alert alert-success back-widget-set text-center">
                        <i class="fa fa-book fa-5x"></i>
                        <?php 
                        try {
                            $sql = "SELECT COUNT(*) as count FROM tblbooks";
                            $query = $dbh->prepare($sql);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_ASSOC);
                            $listdbooks = $result['count'];
                        } catch (PDOException $e) {
                            $listdbooks = 0;
                            error_log($e->getMessage());
                        }
                        ?>
                        <h3><?php echo htmlentities($listdbooks);?></h3>
                        Books Listed
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                    <div class="alert alert-info back-widget-set text-center">
                        <i class="fa fa-bars fa-5x"></i>
                        <?php 
                        try {
                            $sql = "SELECT COUNT(*) as count FROM tblissuedbookdetails";
                            $query = $dbh->prepare($sql);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_ASSOC);
                            $issuedbooks = $result['count'];
                        } catch (PDOException $e) {
                            $issuedbooks = 0;
                            error_log($e->getMessage());
                        }
                        ?>
                        <h3><?php echo htmlentities($issuedbooks);?></h3>
                        Times Book Issued
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                    <div class="alert alert-warning back-widget-set text-center">
                        <i class="fa fa-recycle fa-5x"></i>
                        <?php 
                        try {
                            $sql = "SELECT COUNT(*) as count FROM tblissuedbookdetails WHERE RetrunStatus=1";
                            $query = $dbh->prepare($sql);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_ASSOC);
                            $returnedbooks = $result['count'];
                        } catch (PDOException $e) {
                            $returnedbooks = 0;
                            error_log($e->getMessage());
                        }
                        ?>
                        <h3><?php echo htmlentities($returnedbooks);?></h3>
                        Times Books Returned
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                    <div class="alert alert-danger back-widget-set text-center">
                        <i class="fa fa-users fa-5x"></i>
                        <?php 
                        try {
                            $sql = "SELECT COUNT(*) as count FROM tblstudents";
                            $query = $dbh->prepare($sql);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_ASSOC);
                            $regstds = $result['count'];
                        } catch (PDOException $e) {
                            $regstds = 0;
                            error_log($e->getMessage());
                        }
                        ?>
                        <h3><?php echo htmlentities($regstds);?></h3>
                        Registered Users
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-6">
                    <div class="alert alert-success back-widget-set text-center">
                        <i class="fa fa-user fa-5x"></i>
                        <?php 
                        try {
                            $sql = "SELECT COUNT(*) as count FROM tblauthors";
                            $query = $dbh->prepare($sql);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_ASSOC);
                            $listdathrs = $result['count'];
                        } catch (PDOException $e) {
                            $listdathrs = 0;
                            error_log($e->getMessage());
                        }
                        ?>
                        <h3><?php echo htmlentities($listdathrs);?></h3>
                        Authors Listed
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                    <div class="alert alert-info back-widget-set text-center">
                        <i class="fa fa-file-archive-o fa-5x"></i>
                        <?php 
                        try {
                            $sql = "SELECT COUNT(*) as count FROM tblcategory";
                            $query = $dbh->prepare($sql);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_ASSOC);
                            $listdcats = $result['count'];
                        } catch (PDOException $e) {
                            $listdcats = 0;
                            error_log($e->getMessage());
                        }
                        ?>
                        <h3><?php echo htmlentities($listdcats);?></h3>
                        Listed Categories
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
