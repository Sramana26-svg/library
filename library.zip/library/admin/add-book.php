<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../includes/config.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
} else {
    if(isset($_POST['add'])) {
        $bookname = trim($_POST['bookname']);
        $category = $_POST['category'];
        $author = $_POST['author'];
        $isbn = trim($_POST['isbn']);
        $price = trim($_POST['price']);
        
        try {
            // Check if ISBN already exists
            $check_sql = "SELECT COUNT(*) as count FROM tblbooks WHERE ISBNNumber = :isbn";
            $check_query = $dbh->prepare($check_sql);
            $check_query->bindParam(':isbn', $isbn, PDO::PARAM_STR);
            $check_query->execute();
            $count = $check_query->fetch(PDO::FETCH_ASSOC)['count'];
            
            if($count > 0) {
                $_SESSION['error'] = "ISBN number already exists. Please use a different ISBN.";
            } else {
                $sql = "INSERT INTO tblbooks(BookName, CatId, AuthorId, ISBNNumber, BookPrice, Status) 
                        VALUES(:bookname, :category, :author, :isbn, :price, 1)";
                $query = $dbh->prepare($sql);
                $query->bindParam(':bookname', $bookname, PDO::PARAM_STR);
                $query->bindParam(':category', $category, PDO::PARAM_STR);
                $query->bindParam(':author', $author, PDO::PARAM_STR);
                $query->bindParam(':isbn', $isbn, PDO::PARAM_STR);
                $query->bindParam(':price', $price, PDO::PARAM_STR);
                $query->execute();
                $lastInsertId = $dbh->lastInsertId();
                
                if($lastInsertId) {
                    $_SESSION['msg'] = "Book added successfully";
                    header('location:manage-books.php');
                    exit();
                } else {
                    $_SESSION['error'] = "Something went wrong. Please try again";
                }
            }
        } catch(PDOException $e) {
            $_SESSION['error'] = "Database Error: " . $e->getMessage();
        }
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Add Book</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Add Book</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <?php if(isset($_SESSION['error'])) { ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> <?php echo htmlentities($_SESSION['error']); ?>
                            <?php unset($_SESSION['error']); ?>
                        </div>
                    <?php } ?>
                    <div class="panel panel-info">
                        <div class="panel-heading">Book Information</div>
                        <div class="panel-body">
                            <form role="form" method="post" onSubmit="return validateForm();">
                                <div class="form-group">
                                    <label>Book Name<span style="color:red;">*</span></label>
                                    <input class="form-control" type="text" name="bookname" id="bookname" required />
                                </div>

                                <div class="form-group">
                                    <label>Category<span style="color:red;">*</span></label>
                                    <select class="form-control" name="category" id="category" required>
                                        <option value="">Select Category</option>
                                        <?php 
                                        $sql = "SELECT * FROM tblcategory WHERE Status=1";
                                        $query = $dbh->prepare($sql);
                                        $query->execute();
                                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                                        if($query->rowCount() > 0) {
                                            foreach($results as $result) { ?>
                                                <option value="<?php echo htmlentities($result->id);?>">
                                                    <?php echo htmlentities($result->CategoryName);?>
                                                </option>
                                        <?php }} ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Author<span style="color:red;">*</span></label>
                                    <select class="form-control" name="author" id="author" required>
                                        <option value="">Select Author</option>
                                        <?php 
                                        $sql = "SELECT * FROM tblauthors WHERE Status=1";
                                        $query = $dbh->prepare($sql);
                                        $query->execute();
                                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                                        if($query->rowCount() > 0) {
                                            foreach($results as $result) { ?>
                                                <option value="<?php echo htmlentities($result->id);?>">
                                                    <?php echo htmlentities($result->AuthorName);?>
                                                </option>
                                        <?php }} ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>ISBN Number<span style="color:red;">*</span></label>
                                    <input class="form-control" type="text" name="isbn" id="isbn" required />
                                    <p class="help-block">An ISBN is an International Standard Book Number. ISBN Must be unique</p>
                                </div>

                                <div class="form-group">
                                    <label>Price<span style="color:red;">*</span></label>
                                    <input class="form-control" type="number" name="price" id="price" step="0.01" min="0" required />
                                </div>

                                <button type="submit" name="add" class="btn btn-info">Add Book</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    <!-- FORM VALIDATION -->
    <script type="text/javascript">
    function validateForm() {
        var bookname = document.getElementById('bookname').value.trim();
        var category = document.getElementById('category').value;
        var author = document.getElementById('author').value;
        var isbn = document.getElementById('isbn').value.trim();
        var price = document.getElementById('price').value;

        if(bookname == "") {
            alert("Book name cannot be empty");
            return false;
        }
        if(bookname.length < 2) {
            alert("Book name must be at least 2 characters long");
            return false;
        }
        if(category == "") {
            alert("Please select a category");
            return false;
        }
        if(author == "") {
            alert("Please select an author");
            return false;
        }
        if(isbn == "") {
            alert("ISBN cannot be empty");
            return false;
        }
        // Basic ISBN format validation
        if(!/^\d{10,13}$/.test(isbn)) {
            alert("ISBN must be 10 or 13 digits");
            return false;
        }
        if(isNaN(price) || price <= 0) {
            alert("Please enter a valid price");
            return false;
        }
        return true;
    }
    </script>
</body>
</html>
<?php } ?>
