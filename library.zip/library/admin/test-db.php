<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('../includes/config.php');

try {
    // Test issued books
    echo "<h3>Testing Issued Books Table:</h3>";
    $sql = "SELECT i.*, b.BookName, s.FullName 
            FROM tblissuedbookdetails i 
            JOIN tblbooks b ON b.id = i.BookId
            JOIN tblstudents s ON s.StudentId = i.StudentId";
    $query = $dbh->prepare($sql);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);
    
    echo "Found " . $query->rowCount() . " issued books<br>";
    foreach($results as $result) {
        echo "Book: " . $result->BookName . " - Student: " . $result->FullName . "<br>";
    }

    // Test books table
    echo "<h3>Testing Books Table:</h3>";
    $sql = "SELECT * FROM tblbooks";
    $query = $dbh->prepare($sql);
    $query->execute();
    echo "Found " . $query->rowCount() . " books<br>";
    
    // Test categories table
    echo "<h3>Testing Categories Table:</h3>";
    $sql = "SELECT * FROM tblcategory";
    $query = $dbh->prepare($sql);
    $query->execute();
    echo "Found " . $query->rowCount() . " categories<br>";
    
    // Test authors table
    echo "<h3>Testing Authors Table:</h3>";
    $sql = "SELECT * FROM tblauthors";
    $query = $dbh->prepare($sql);
    $query->execute();
    echo "Found " . $query->rowCount() . " authors<br>";

} catch(PDOException $e) {
    echo "Database Error: " . $e->getMessage();
}
?>