<?php
session_start(); 
// Unset all relevant session variables
unset(
    $_SESSION['login'],
    $_SESSION['alogin'],
    $_SESSION['adminid'],
    $_SESSION['fullname'],
    $_SESSION['stdid']
);
$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 60*60,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy(); // destroy session
header("location:../adminlogin.php"); 
?>

