<?php 
require_once(__DIR__ . '/../includes/config.php');
header('Content-Type: application/json');

if(empty($_POST["studentid"])) {
    echo json_encode(['error' => 'Student ID is required']);
    exit();
}

try {
    $studentid = strtoupper(trim($_POST["studentid"]));
    
    // Get student details including number of books currently issued
    $sql = "SELECT s.FullName, s.Status, s.EmailId,
            (SELECT COUNT(*) FROM tblissuedbookdetails 
             WHERE StudentId = s.StudentId AND RetrunStatus = 0) as BooksIssued
            FROM tblstudents s 
            WHERE s.StudentId = :studentid";
            
    $query = $dbh->prepare($sql);
    $query->bindParam(':studentid', $studentid, PDO::PARAM_STR);
    $query->execute();
    
    if($query->rowCount() > 0) {
        $result = $query->fetch(PDO::FETCH_ASSOC);
        
        if($result['Status'] == 0) {
            echo json_encode([
                'success' => false,
                'message' => '<span class="text-danger">This student account is blocked</span>',
                'status' => 'blocked',
                'data' => $result
            ]);
        } else if($result['BooksIssued'] >= 3) {
            echo json_encode([
                'success' => false,
                'message' => '<span class="text-warning">Student has already issued maximum allowed books (3)</span>',
                'status' => 'max_books',
                'data' => $result
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'message' => '<span class="text-success">Student: ' . htmlspecialchars($result['FullName']) . 
                           ' (Books currently issued: ' . $result['BooksIssued'] . ')</span>',
                'status' => 'active',
                'data' => $result
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => '<span class="text-danger">Invalid Student ID. Please enter a valid Student ID.</span>',
            'status' => 'not_found'
        ]);
    }
} catch(PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode([
        'error' => 'An error occurred while fetching student information'
    ]);
}
?>
