<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include(__DIR__ . '/includes/config.php');

$errorMsg = '';
if(isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);
    try {
        $sql = "SELECT id, FullName, UserName FROM admin WHERE UserName=:username AND Password=:password";
        $query = $dbh->prepare($sql);
        $query->bindParam(':username', $username, PDO::PARAM_STR);
        $query->bindParam(':password', $password, PDO::PARAM_STR);
        $query->execute();
        if($query->rowCount() > 0) {
            $result = $query->fetch(PDO::FETCH_OBJ);
            $_SESSION['alogin'] = $result->UserName;
            $_SESSION['adminid'] = $result->id;
            $_SESSION['fullname'] = $result->FullName;
            header('location:dashboard.php');
            exit();
        } else {
            $errorMsg = 'Invalid Username or Password';
        }
    } catch(PDOException $e) {
        $errorMsg = 'Database Error: ' . htmlentities($e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <!------MENU SECTION START-->
    <?php include(__DIR__ . '/includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <!-- Vibrant Banner -->
            <div class="row">
                <div class="col-md-12">
                    <div style="background: linear-gradient(90deg, #ffecd2 0%, #fcb69f 100%); border-radius: 18px; box-shadow: 0 4px 24px rgba(252,182,159,0.12); margin-bottom: 32px; padding: 32px 0; text-align:center;">
                        <span style="color:#dd2476; font-size:2.2em; font-weight:bold; text-shadow:0 2px 12px #fcb69f; letter-spacing:2px;">Admin Portal Login</span>
                    </div>
                </div>
            </div>
            <!-- Image Cards Row -->
            <div class="row" style="margin-bottom:32px;">
                <div class="col-md-4">
                    <div class="panel panel-info text-center" style="padding:16px;">
                        <img src="assets/img/2.jpg" alt="Manage Books" style="width:100%; border-radius:12px; margin-bottom:12px; max-height:120px; object-fit:cover;">
                        <h4>Manage Books</h4>
                        <p>Effortlessly add, edit, and organize your library's collection.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-success text-center" style="padding:16px;">
                        <img src="assets/img/3.jpg" alt="Track Users" style="width:100%; border-radius:12px; margin-bottom:12px; max-height:120px; object-fit:cover;">
                        <h4>Track Users</h4>
                        <p>Monitor student activity and issued books with ease.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-warning text-center" style="padding:16px;">
                        <img src="assets/img/user2.png" alt="Admin Tools" style="width:100%; border-radius:12px; margin-bottom:12px; max-height:120px; object-fit:cover; background:#fff;">
                        <h4>Admin Tools</h4>
                        <p>Access powerful tools to keep your library running smoothly.</p>
                    </div>
                </div>
            </div>
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">ADMIN LOGIN FORM</h4>
                </div>
            </div>
            <!--LOGIN PANEL START-->           
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <div class="panel panel-info">
                        <div class="panel-heading">LOGIN FORM</div>
                        <div class="panel-body">
                        <?php if($errorMsg) { ?>
                            <div class="alert alert-danger text-center"><?php echo $errorMsg; ?></div>
                        <?php } ?>
                            <form role="form" method="post" id="adminLoginForm">
                                <div class="form-group">
                                    <label>Enter Username</label>
                                    <input class="form-control" type="text" name="username" id="username" required />
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="form-control" type="password" name="password" id="password" required />
                                </div>
                                <button type="submit" name="login" class="btn btn-info">LOGIN</button>
                            </form>
                            <div id="formError" class="alert alert-danger text-center" style="display:none;"></div>
                        </div>
                    </div>
                </div>
            </div>  
            <!---LOGIN PANEL END-->            
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include(__DIR__ . '/includes/footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    <script type="text/javascript">
    document.getElementById('adminLoginForm').onsubmit = function() {
        var username = document.getElementById('username').value.trim();
        var password = document.getElementById('password').value;
        var formError = document.getElementById('formError');
        if(username === "" || password === "") {
            formError.textContent = "Username and Password cannot be empty";
            formError.style.display = 'block';
            return false;
        }
        formError.style.display = 'none';
        return true;
    };
    </script>
</body>
</html>
