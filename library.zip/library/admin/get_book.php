<?php 
require_once(__DIR__ . '/../includes/config.php');
header('Content-Type: application/json');

if(empty($_POST["searchTerm"])) {
    echo json_encode(['error' => 'Search term is required']);
    exit();
}

try {
    $searchTerm = trim($_POST["searchTerm"]);
    
    // Search by ISBN or Book Name
    $sql = "SELECT b.id, b.BookName, b.ISBNNumber, a.AuthorName, c.CategoryName, b.Status 
            FROM tblbooks b 
            LEFT JOIN tblauthors a ON a.id = b.AuthorId
            LEFT JOIN tblcategory c ON c.id = b.CatId
            WHERE (b.ISBNNumber LIKE :search 
                  OR b.BookName LIKE :search)
            AND b.Status = 1
            LIMIT 10";
            
    $query = $dbh->prepare($sql);
    $searchPattern = "%$searchTerm%";
    $query->bindParam(':search', $searchPattern, PDO::PARAM_STR);
    $query->execute();
    
    if($query->rowCount() > 0) {
        $options = [];
        while($result = $query->fetch(PDO::FETCH_ASSOC)) {
            $options[] = [
                'value' => $result['id'],
                'text' => htmlspecialchars($result['BookName'] . ' - ' . $result['AuthorName'] . 
                         ' (ISBN: ' . $result['ISBNNumber'] . ')')
            ];
        }
        echo json_encode([
            'success' => true,
            'options' => $options
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No books found matching your search'
        ]);
    }
} catch(PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode([
        'error' => 'An error occurred while searching for books'
    ]);
}
?>
