<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

try {
    // List all tables and their record counts
    $tables = array('tblbooks', 'tblcategory', 'tblauthors', 'tblstudents', 'tblissuedbookdetails');
    
    echo "<h3>Database Table Status:</h3>";
    foreach($tables as $table) {
        $sql = "SELECT COUNT(*) as count FROM $table";
        $query = $dbh->prepare($sql);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);
        echo "$table: {$result['count']} records<br>";
        
        // Show sample data from each table
        $sql = "SELECT * FROM $table LIMIT 1";
        $query = $dbh->prepare($sql);
        $query->execute();
        if($query->rowCount() > 0) {
            $row = $query->fetch(PDO::FETCH_ASSOC);
            echo "Sample record: <pre>" . print_r($row, true) . "</pre><br>";
        }
    }
    
} catch(PDOException $e) {
    echo "Database Error: " . $e->getMessage();
}
?>