<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
    exit();
} 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | Manage Issued Books</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Manage Issued Books</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Issued Books</div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Student Name</th>
                                            <th>Book Name</th>
                                            <th>ISBN</th>
                                            <th>Issued Date</th>
                                            <th>Return Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    $sql = "SELECT tblstudents.FullName,tblbooks.BookName,tblbooks.ISBNNumber,tblissuedbookdetails.IssuesDate,tblissuedbookdetails.ReturnDate,tblissuedbookdetails.id as rid,tblissuedbookdetails.fine,tblissuedbookdetails.RetrunStatus,DATEDIFF(CURDATE(),tblissuedbookdetails.IssuesDate) as days_elapsed
                                    FROM tblissuedbookdetails
                                    JOIN tblstudents ON tblstudents.StudentId=tblissuedbookdetails.StudentId
                                    JOIN tblbooks ON tblbooks.id=tblissuedbookdetails.BookId
                                    ORDER BY tblissuedbookdetails.id DESC";
                                    $query = $dbh->prepare($sql);
                                    $query->execute();
                                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                                    $cnt=1;
                                    if($query->rowCount() > 0) {
                                        foreach($results as $result) {
                                            $fine_per_day = 1.00; // $1 per day after due date (14 days)
                                            $due_days = 14;
                                            $days_overdue = max(0, $result->days_elapsed - $due_days);
                                            $calculated_fine = $days_overdue * $fine_per_day;
                                    ?>
                                            <tr class="odd gradeX">
                                                <td class="center"><?php echo htmlentities($cnt);?></td>
                                                <td class="center"><?php echo htmlentities($result->FullName);?></td>
                                                <td class="center"><?php echo htmlentities($result->BookName);?></td>
                                                <td class="center"><?php echo htmlentities($result->ISBNNumber);?></td>
                                                <td class="center"><?php echo htmlentities($result->IssuesDate);?></td>
                                                <td class="center"><?php if($result->ReturnDate=="") {
                                                                            echo '<span class="label label-danger">Not Returned Yet</span>';
                                                                        } else {
                                                                            echo htmlentities($result->ReturnDate);
                                                                        } ?>
                                                </td>
                                                <td class="center"><?php if($result->RetrunStatus==0) {
                                                                            echo '<span class="label label-danger">Not Returned</span>';
                                                                            if($days_overdue > 0) {
                                                                                echo '<br><span class="label label-warning">Overdue by ' . $days_overdue . ' days</span>';
                                                                                echo '<br>Estimated Fine: $' . number_format($calculated_fine, 2);
                                                                            }
                                                                        } else {
                                                                            echo '<span class="label label-success">Returned</span>';
                                                                            if($result->fine > 0) {
                                                                                echo '<br>Fine Paid: $' . number_format($result->fine, 2);
                                                                            }
                                                                        } ?>
                                                </td>
                                                <td class="center">
                                                <?php if($result->RetrunStatus==0) { ?>
                                                    <a href="update-issue-bookdeails.php?rid=<?php echo htmlentities($result->rid);?>">
                                                        <button class="btn btn-primary" type="button">Return Book</button>
                                                    </a>
                                                <?php } ?>
                                                </td>
                                            </tr>
                                    <?php $cnt=$cnt+1;}} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
