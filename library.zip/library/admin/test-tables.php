<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../includes/config.php');

try {
    // Test students table
    $sql = "SELECT COUNT(*) as count FROM tblstudents";
    $query = $dbh->prepare($sql);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);
    echo "Number of students: " . $result['count'] . "<br>";

    // Test books table
    $sql = "SELECT COUNT(*) as count FROM tblbooks";
    $query = $dbh->prepare($sql);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);
    echo "Number of books: " . $result['count'] . "<br>";

    // Show all tables and their record counts
    $tables = array('tblbooks', 'tblstudents', 'tblauthors', 'tblcategory', 'tblissuedbookdetails');
    foreach($tables as $table) {
        $sql = "SELECT COUNT(*) as count FROM $table";
        $query = $dbh->prepare($sql);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);
        echo "Table $table has: " . $result['count'] . " records<br>";
        
        // Show first record from each table
        $sql = "SELECT * FROM $table LIMIT 1";
        $query = $dbh->prepare($sql);
        $query->execute();
        if($query->rowCount() > 0) {
            $row = $query->fetch(PDO::FETCH_ASSOC);
            echo "Sample record from $table: <pre>" . print_r($row, true) . "</pre><br>";
        }
    }

} catch(PDOException $e) {
    echo "Database Error: " . $e->getMessage();
}
?>