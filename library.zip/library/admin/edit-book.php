<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
} else {
    if(isset($_POST['update'])) {
        $bookname = trim($_POST['bookname']);
        $category = $_POST['category'];
        $author = $_POST['author'];
        $isbn = trim($_POST['isbn']);
        $price = trim($_POST['price']);
        $bookid = intval($_GET['bookid']);
        $status = $_POST['status'];
        
        try {
            // Check if ISBN exists for other books
            $check_sql = "SELECT COUNT(*) as count FROM tblbooks WHERE ISBNNumber = :isbn AND id != :bookid";
            $check_query = $dbh->prepare($check_sql);
            $check_query->bindParam(':isbn', $isbn, PDO::PARAM_STR);
            $check_query->bindParam(':bookid', $bookid, PDO::PARAM_STR);
            $check_query->execute();
            $count = $check_query->fetch(PDO::FETCH_ASSOC)['count'];
            
            if($count > 0) {
                $_SESSION['error'] = "This ISBN is already used by another book";
            } else {
                $sql = "UPDATE tblbooks SET 
                        BookName=:bookname,
                        CatId=:category,
                        AuthorId=:author,
                        ISBNNumber=:isbn,
                        BookPrice=:price,
                        Status=:status 
                        WHERE id=:bookid";
                $query = $dbh->prepare($sql);
                $query->bindParam(':bookname', $bookname, PDO::PARAM_STR);
                $query->bindParam(':category', $category, PDO::PARAM_STR);
                $query->bindParam(':author', $author, PDO::PARAM_STR);
                $query->bindParam(':isbn', $isbn, PDO::PARAM_STR);
                $query->bindParam(':price', $price, PDO::PARAM_STR);
                $query->bindParam(':status', $status, PDO::PARAM_STR);
                $query->bindParam(':bookid', $bookid, PDO::PARAM_STR);
                $query->execute();

                $_SESSION['msg'] = "Book information updated successfully";
                header('location:manage-books.php');
                exit();
            }
        } catch(PDOException $e) {
            $_SESSION['error'] = "Database Error: " . $e->getMessage();
        }
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Edit Book</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Edit Book</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <?php if(isset($_SESSION['error'])) { ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> <?php echo htmlentities($_SESSION['error']); ?>
                            <?php unset($_SESSION['error']); ?>
                        </div>
                    <?php } ?>
                    <div class="panel panel-info">
                        <div class="panel-heading">Book Information</div>
                        <div class="panel-body">
                            <form role="form" method="post" onSubmit="return validateForm();">
                                <?php 
                                $bookid = intval($_GET['bookid']);
                                $sql = "SELECT b.BookName, b.Status,
                                              c.CategoryName, c.id as cid,
                                              a.AuthorName, a.id as athrid,
                                              b.ISBNNumber, b.BookPrice, b.id as bookid 
                                       FROM tblbooks b 
                                       JOIN tblcategory c ON c.id=b.CatId 
                                       JOIN tblauthors a ON a.id=b.AuthorId 
                                       WHERE b.id=:bookid";
                                $query = $dbh->prepare($sql);
                                $query->bindParam(':bookid', $bookid, PDO::PARAM_STR);
                                $query->execute();
                                
                                if($query->rowCount() > 0) {
                                    $result = $query->fetch(PDO::FETCH_OBJ);
                                ?>
                                <div class="form-group">
                                    <label>Book Name<span style="color:red;">*</span></label>
                                    <input class="form-control" type="text" name="bookname" id="bookname" 
                                           value="<?php echo htmlentities($result->BookName);?>" required />
                                </div>

                                <div class="form-group">
                                    <label>Category<span style="color:red;">*</span></label>
                                    <select class="form-control" name="category" id="category" required>
                                        <option value="<?php echo htmlentities($result->cid);?>">
                                            <?php echo htmlentities($result->CategoryName);?>
                                        </option>
                                        <?php 
                                        $sql1 = "SELECT * FROM tblcategory WHERE Status=1 AND id != :cid";
                                        $query1 = $dbh->prepare($sql1);
                                        $query1->bindParam(':cid', $result->cid, PDO::PARAM_STR);
                                        $query1->execute();
                                        $results1 = $query1->fetchAll(PDO::FETCH_OBJ);
                                        if($query1->rowCount() > 0) {
                                            foreach($results1 as $result1) { ?>
                                                <option value="<?php echo htmlentities($result1->id);?>">
                                                    <?php echo htmlentities($result1->CategoryName);?>
                                                </option>
                                        <?php }} ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Author<span style="color:red;">*</span></label>
                                    <select class="form-control" name="author" id="author" required>
                                        <option value="<?php echo htmlentities($result->athrid);?>">
                                            <?php echo htmlentities($result->AuthorName);?>
                                        </option>
                                        <?php 
                                        $sql2 = "SELECT * FROM tblauthors WHERE Status=1 AND id != :athrid";
                                        $query2 = $dbh->prepare($sql2);
                                        $query2->bindParam(':athrid', $result->athrid, PDO::PARAM_STR);
                                        $query2->execute();
                                        $results2 = $query2->fetchAll(PDO::FETCH_OBJ);
                                        if($query2->rowCount() > 0) {
                                            foreach($results2 as $result2) { ?>
                                                <option value="<?php echo htmlentities($result2->id);?>">
                                                    <?php echo htmlentities($result2->AuthorName);?>
                                                </option>
                                        <?php }} ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>ISBN Number<span style="color:red;">*</span></label>
                                    <input class="form-control" type="text" name="isbn" id="isbn" 
                                           value="<?php echo htmlentities($result->ISBNNumber);?>" required />
                                    <p class="help-block">An ISBN is an International Standard Book Number. ISBN Must be unique</p>
                                </div>

                                <div class="form-group">
                                    <label>Price<span style="color:red;">*</span></label>
                                    <input class="form-control" type="number" name="price" id="price" step="0.01" min="0"
                                           value="<?php echo htmlentities($result->BookPrice);?>" required />
                                </div>

                                <div class="form-group">
                                    <label>Status</label>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="status" id="status1" value="1" 
                                                   <?php if($result->Status == 1) echo 'checked="checked"'; ?>>Active
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="status" id="status2" value="0"
                                                   <?php if($result->Status == 0) echo 'checked="checked"'; ?>>Inactive
                                        </label>
                                    </div>
                                </div>

                                <button type="submit" name="update" class="btn btn-info">Update Book</button>
                            </form>
                            <?php } else { ?>
                                <div class="alert alert-danger">Invalid book ID.</div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    <!-- FORM VALIDATION -->
    <script type="text/javascript">
    function validateForm() {
        var bookname = document.getElementById('bookname').value.trim();
        var category = document.getElementById('category').value;
        var author = document.getElementById('author').value;
        var isbn = document.getElementById('isbn').value.trim();
        var price = document.getElementById('price').value;

        if(bookname == "") {
            alert("Book name cannot be empty");
            return false;
        }
        if(bookname.length < 2) {
            alert("Book name must be at least 2 characters long");
            return false;
        }
        if(category == "") {
            alert("Please select a category");
            return false;
        }
        if(author == "") {
            alert("Please select an author");
            return false;
        }
        if(isbn == "") {
            alert("ISBN cannot be empty");
            return false;
        }
        // Basic ISBN format validation
        if(!/^\d{10,13}$/.test(isbn)) {
            alert("ISBN must be 10 or 13 digits");
            return false;
        }
        if(isNaN(price) || price <= 0) {
            alert("Please enter a valid price");
            return false;
        }
        return true;
    }
    </script>
</body>
</html>
<?php } ?>
