﻿/*=============================================================
    Authour URI: www.binarytheme.com
    License: Commons Attribution 3.0

    http://creativecommons.org/licenses/by/3.0/

    100% Free To use For Personal And Commercial Use.
    IN EXCHANGE JUST GIVE US CREDITS AND TELL YOUR FRIENDS ABOUT US
   
    ========================================================  */

(function ($) {
    "use strict";
    var mainApp = {
        main_fun: function () {
            // Initialize dropdowns
            $('.dropdown-toggle').dropdown();
            
            // Add hover effect for desktop
            if ($(window).width() > 768) {
                $('.dropdown').hover(
                    function() { $(this).addClass('open'); },
                    function() { $(this).removeClass('open'); }
                );
            }
            
            // Set active menu item
            var currentUrl = window.location.pathname.split('/').pop();
            $('.nav li a').each(function() {
                if ($(this).attr('href') === currentUrl) {
                    $(this).parent().addClass('active');
                    $(this).closest('.dropdown').addClass('active');
                }
            });

            // Initialize DataTables
            if ($.fn.dataTable) {
                $('#dataTables-example').dataTable({
                    "pageLength": 10,
                    "aaSorting": [[0, 'asc']],
                    "responsive": true
                });
            }

            // Form validation helpers
            $('form').on('submit', function() {
                var $form = $(this);
                var $requiredFields = $form.find('[required]');
                var valid = true;

                $requiredFields.each(function() {
                    if (!$(this).val().trim()) {
                        valid = false;
                        $(this).addClass('error').parent().addClass('has-error');
                    } else {
                        $(this).removeClass('error').parent().removeClass('has-error');
                    }
                });

                if (!valid) {
                    alert('Please fill in all required fields');
                    return false;
                }

                return true;
            });

            // Real-time validation feedback
            $('input, select').on('change keyup', function() {
                if ($(this).val().trim()) {
                    $(this).removeClass('error').parent().removeClass('has-error');
                }
            });
        },
        initialization: function () {
            mainApp.main_fun();
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function () {
        mainApp.initialization();
    });
}(jQuery));


