<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
    exit();
} else { 
    if(isset($_POST['issue'])) {
        try {
            $studentid = strtoupper(trim($_POST['studentid']));
            $bookid = intval($_POST['bookdetails']);

            // Start transaction early for concurrency control
            $dbh->beginTransaction();

            // Verify student exists and is active
            $check_student = "SELECT Status FROM tblstudents WHERE StudentId=:studentid FOR UPDATE";
            $stmt = $dbh->prepare($check_student);
            $stmt->bindParam(':studentid', $studentid, PDO::PARAM_STR);
            $stmt->execute();
            if($stmt->rowCount() == 0) {
                throw new Exception("Student ID not found");
            }
            $student_status = $stmt->fetch(PDO::FETCH_ASSOC)['Status'];
            if($student_status != 1) {
                throw new Exception("Student account is not active");
            }

            // Lock the book row for update
            $check_book = "SELECT Status, IssuedCount FROM tblbooks WHERE id=:bookid FOR UPDATE";
            $stmt = $dbh->prepare($check_book);
            $stmt->bindParam(':bookid', $bookid, PDO::PARAM_INT);
            $stmt->execute();
            if($stmt->rowCount() == 0) {
                throw new Exception("Book not found");
            }
            $book = $stmt->fetch(PDO::FETCH_ASSOC);
            if($book['Status'] != 1) {
                throw new Exception("Book is not available for issue");
            }

            // Check if student has already issued this book
            $check_issued = "SELECT id FROM tblissuedbookdetails WHERE StudentId=:studentid AND BookId=:bookid AND RetrunStatus=0 FOR UPDATE";
            $stmt = $dbh->prepare($check_issued);
            $stmt->bindParam(':studentid', $studentid, PDO::PARAM_STR);
            $stmt->bindParam(':bookid', $bookid, PDO::PARAM_INT);
            $stmt->execute();
            if($stmt->rowCount() > 0) {
                throw new Exception("This book is already issued to this student");
            }

            // Insert issue record
            $sql = "INSERT INTO tblissuedbookdetails(StudentID, BookId, IssuesDate) VALUES(:studentid, :bookid, NOW())";
            $query = $dbh->prepare($sql);
            $query->bindParam(':studentid', $studentid, PDO::PARAM_STR);
            $query->bindParam(':bookid', $bookid, PDO::PARAM_INT);
            $query->execute();

            // Update book issued count
            $update_book = "UPDATE tblbooks SET IssuedCount = IssuedCount + 1 WHERE id = :bookid";
            $stmt = $dbh->prepare($update_book);
            $stmt->bindParam(':bookid', $bookid, PDO::PARAM_INT);
            $stmt->execute();

            $dbh->commit();
            $_SESSION['msg'] = "Book issued successfully";
            header('location:manage-issued-books.php');
            exit();

        } catch(Exception $e) {
            if($dbh->inTransaction()) {
                $dbh->rollBack();
            }
            $_SESSION['error'] = "Error: " . $e->getMessage();
        }
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Issue a new Book</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Issue a New Book</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-10 col-sm-6 col-xs-12 col-md-offset-1">
                    <?php if(isset($_SESSION['error'])) { ?>
                        <div class="alert alert-danger">
                            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        </div>
                    <?php } ?>
                    <div class="panel panel-info">
                        <div class="panel-heading">Issue a New Book</div>
                        <div class="panel-body">
                            <form role="form" method="post" onSubmit="return validateForm();">
                                <div class="form-group">
                                    <label>Student ID<span style="color:red;">*</span></label>
                                    <input class="form-control" type="text" name="studentid" id="studentid" 
                                           onBlur="getstudent()" autocomplete="off" required />
                                    <span id="get_student_name" class="help-block"></span>
                                </div>

                                <div class="form-group">
                                    <label>ISBN Number or Book Title<span style="color:red;">*</span></label>
                                    <input class="form-control" type="text" name="bookid" id="bookid" 
                                           onBlur="getbook()" required />
                                    <div class="help-block">Enter ISBN or book title to search</div>
                                </div>

                                <div class="form-group">
                                    <label>Select Book<span style="color:red;">*</span></label>
                                    <select class="form-control" name="bookdetails" id="get_book_name" required>
                                        <option value="">Select Book</option>
                                    </select>
                                </div>

                                <button type="submit" name="issue" id="submit" class="btn btn-info">
                                    Issue Book
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    <script>
    function getstudent() {
        var studentid = $("#studentid").val().trim();
        if(studentid.length > 0) {
            $("#loaderIcon").show();
            $.ajax({
                url: "get_student.php",
                data: { studentid: studentid },
                type: "POST",
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        $("#get_student_name").html(response.message);
                        $('#submit').prop('disabled', false);
                    } else {
                        $("#get_student_name").html(response.message);
                        $('#submit').prop('disabled', true);
                    }
                    $("#loaderIcon").hide();
                },
                error: function() {
                    $("#get_student_name").html('<span class="text-danger">Error getting student info</span>');
                    $("#loaderIcon").hide();
                    $('#submit').prop('disabled', true);
                }
            });
        }
    }

    function getbook() {
        var searchTerm = $("#bookid").val().trim();
        if(searchTerm.length > 0) {
            $("#loaderIcon").show();
            $.ajax({
                url: "get_book.php",
                data: { searchTerm: searchTerm },
                type: "POST",
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        var select = $("#get_book_name");
                        select.empty();
                        select.append('<option value="">Select Book</option>');
                        response.options.forEach(function(option) {
                            select.append($('<option></option>')
                                .attr('value', option.value)
                                .text(option.text));
                        });
                    } else {
                        $("#get_book_name").html('<option value="">' + (response.message || 'No books found') + '</option>');
                    }
                    $("#loaderIcon").hide();
                },
                error: function() {
                    $("#get_book_name").html('<option value="">Error loading books</option>');
                    $("#loaderIcon").hide();
                }
            });
        }
    }

    function validateForm() {
        var studentid = $("#studentid").val().trim();
        var bookdetails = $("#get_book_name").val();
        
        if(studentid == "") {
            alert("Please enter Student ID");
            return false;
        }
        if(bookdetails == "") {
            alert("Please select a book");
            return false;
        }
        return true;
    }
    </script>
</body>
</html>
<?php } ?>
