<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include(__DIR__ . '/../includes/config.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
} else {
    // Handle student status updates
    if(isset($_GET['inid']) || isset($_GET['id'])) {
        $studentId = isset($_GET['inid']) ? $_GET['inid'] : $_GET['id'];
        $status = isset($_GET['inid']) ? 0 : 1;
        
        try {
            $sql = "UPDATE tblstudents SET Status=:status WHERE id=:id";
            $query = $dbh->prepare($sql);
            $query->bindParam(':id', $studentId, PDO::PARAM_STR);
            $query->bindParam(':status', $status, PDO::PARAM_STR);
            $query->execute();
            $_SESSION['msg'] = "Student status updated successfully";
            header('location:reg-students.php');
            exit();
        } catch(PDOException $e) {
            $_SESSION['error'] = "Error updating student status: " . $e->getMessage();
        }
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Manage Registered Students</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Manage Registered Students</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php if(isset($_SESSION['error'])) { ?>
                        <div class="alert alert-danger">
                            <strong>Error:</strong> <?php echo htmlentities($_SESSION['error']); ?>
                            <?php unset($_SESSION['error']); ?>
                        </div>
                    <?php } ?>
                    <?php if(isset($_SESSION['msg'])) { ?>
                        <div class="alert alert-success">
                            <strong>Success:</strong> <?php echo htmlentities($_SESSION['msg']); ?>
                            <?php unset($_SESSION['msg']); ?>
                        </div>
                    <?php } ?>
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Registered Students</div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Student ID</th>
                                            <th>Student Name</th>
                                            <th>Email ID</th>
                                            <th>Mobile Number</th>
                                            <th>Registration Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    try {
                                        $sql = "SELECT * FROM tblstudents ORDER BY RegDate DESC";
                                        $query = $dbh->prepare($sql);
                                        $query->execute();
                                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                                        $cnt = 1;
                                        
                                        if($query->rowCount() > 0) {
                                            foreach($results as $result) { ?>
                                                <tr class="odd gradeX">
                                                    <td class="center"><?php echo htmlentities($cnt);?></td>
                                                    <td class="center"><?php echo htmlentities($result->StudentId);?></td>
                                                    <td class="center"><?php echo htmlentities($result->FullName);?></td>
                                                    <td class="center"><?php echo htmlentities($result->EmailId);?></td>
                                                    <td class="center"><?php echo htmlentities($result->MobileNumber);?></td>
                                                    <td class="center"><?php echo htmlentities($result->RegDate);?></td>
                                                    <td class="center">
                                                        <?php if($result->Status == 1) { ?>
                                                            <span class="label label-success">Active</span>
                                                        <?php } else { ?>
                                                            <span class="label label-danger">Blocked</span>
                                                        <?php } ?>
                                                    </td>
                                                    <td class="center">
                                                        <?php if($result->Status == 1) { ?>
                                                            <a href="reg-students.php?inid=<?php echo htmlentities($result->id);?>" 
                                                               onclick="return confirm('Are you sure you want to block this student?');" 
                                                               class="btn btn-danger btn-xs">
                                                                <i class="fa fa-ban"></i> Block
                                                            </a>
                                                        <?php } else { ?>
                                                            <a href="reg-students.php?id=<?php echo htmlentities($result->id);?>" 
                                                               onclick="return confirm('Are you sure you want to activate this student?');" 
                                                               class="btn btn-primary btn-xs">
                                                                <i class="fa fa-check"></i> Activate
                                                            </a>
                                                        <?php } ?>
                                                    </td>
                                                </tr>
                                    <?php $cnt++; }
                                        } else { ?>
                                            <tr>
                                                <td colspan="8" class="text-center">No registered students found</td>
                                            </tr>
                                    <?php }
                                    } catch(PDOException $e) {
                                        echo "<tr><td colspan='8' class='text-danger'>Database Error: " . $e->getMessage() . "</td></tr>";
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
