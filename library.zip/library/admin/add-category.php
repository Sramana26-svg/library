<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include(__DIR__ . '/../includes/config.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
} else { 
    if(isset($_POST['create'])) {
        $category = trim($_POST['category']);
        $status = $_POST['status'];
        
        try {
            $sql = "INSERT INTO tblcategory(CategoryName, Status, CreationDate) VALUES(:category, :status, NOW())";
            $query = $dbh->prepare($sql);
            $query->bindParam(':category', $category, PDO::PARAM_STR);
            $query->bindParam(':status', $status, PDO::PARAM_STR);
            $query->execute();
            $lastInsertId = $dbh->lastInsertId();
            
            if($lastInsertId) {
                $_SESSION['msg'] = "Category added successfully";
            } else {
                $_SESSION['error'] = "Something went wrong. Please try again";
            }
            header('location:manage-categories.php');
            exit();
        } catch(PDOException $e) {
            $_SESSION['error'] = "Database Error: " . $e->getMessage();
        }
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Add Categories</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Add Category</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <?php if(isset($_SESSION['error'])) { ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> <?php echo htmlentities($_SESSION['error']); ?>
                            <?php unset($_SESSION['error']); ?>
                        </div>
                    <?php } ?>
                    <div class="panel panel-info">
                        <div class="panel-heading">Category Information</div>
                        <div class="panel-body">
                            <form role="form" method="post" onSubmit="return validateForm();">
                                <div class="form-group">
                                    <label>Category Name</label>
                                    <input class="form-control" type="text" name="category" id="category" autocomplete="off" required />
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="status" id="status1" value="1" checked="checked">Active
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="status" id="status2" value="0">Inactive
                                        </label>
                                    </div>
                                </div>
                                <button type="submit" name="create" class="btn btn-info">Create Category</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    <!-- FORM VALIDATION -->
    <script type="text/javascript">
    function validateForm() {
        var category = document.getElementById('category').value.trim();
        if(category == "") {
            alert("Category name cannot be empty");
            return false;
        }
        if(category.length < 3) {
            alert("Category name must be at least 3 characters long");
            return false;
        }
        return true;
    }
    </script>
</body>
</html>
<?php } ?>
