<?php
// Bridge to main config file
include(__DIR__ . '/../../includes/config.php');
?>