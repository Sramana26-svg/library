<div class="navbar navbar-inverse set-radius-zero" style="background: linear-gradient(90deg, #ff512f 0%, #dd2476 100%) !important; border-bottom: 5px solid #ff6a00; box-shadow: 0 2px 8px rgba(221,36,118,0.08);">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand">
                <img src="assets/img/logo.png" />
            </a>
        </div>
        <div class="right-div">
            <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
        </div>
    </div>
</div>

<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="dashboard.php">DASHBOARD</a></li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Categories <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="add-category.php">Add Category</a></li>
                                <li><a href="manage-categories.php">Manage Categories</a></li>
                            </ul>
                        </li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Authors <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="add-author.php">Add Author</a></li>
                                <li><a href="manage-authors.php">Manage Authors</a></li>
                            </ul>
                        </li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Books <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="add-book.php">Add Book</a></li>
                                <li><a href="manage-books.php">Manage Books</a></li>
                            </ul>
                        </li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Issue Books <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="issue-book.php">Issue New Book</a></li>
                                <li><a href="manage-issued-books.php">Manage Issued Books</a></li>
                            </ul>
                        </li>
                        
                        <li><a href="reg-students.php">Reg Students</a></li>
                        <li><a href="change-password.php">Change Password</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Load jQuery and Bootstrap JS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script>
jQuery(document).ready(function($) {
    // Initialize dropdowns
    $('.dropdown-toggle').dropdown();
    
    // Add hover functionality for desktop devices
    if($(window).width() > 768) {
        $('.dropdown').hover(
            function() { $(this).addClass('open'); },
            function() { $(this).removeClass('open'); }
        );
    }
    
    // Set active menu item
    var currentUrl = window.location.href.split('/').pop();
    $('.nav li a').each(function() {
        if ($(this).attr('href') === currentUrl) {
            $(this).parent().addClass('active');
            $(this).closest('.dropdown').addClass('active');
        }
    });
});</script>