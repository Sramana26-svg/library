<?php 
header('Content-Type: image/jpeg'); // Add this header to ensure the browser interprets the output as an image
session_start(); 

// Debugging: Check if session is starting properly
if (!isset($_SESSION)) {
    die('Session is not starting properly. Please check your PHP configuration.');
}

// Check if GD library is enabled
if (!function_exists('imagecreate')) {
    die('GD library is not enabled. Please enable it in your PHP configuration.');
}

$text = rand(10000,99999); 
$_SESSION["vercode"] = $text; 
$height = 40; // Increased height for better visibility
$width = 100; // Increased width for better visibility
$image_p = imagecreate($width, $height); 
$black = imagecolorallocate($image_p, 0, 0, 0); 
$white = imagecolorallocate($image_p, 255, 255, 255); 
$font_size = 5; // Adjusted font size to match GD library's built-in fonts

// Fill the background with black
imagefill($image_p, 0, 0, $black);

// Add the text to the image
imagestring($image_p, $font_size, 10, 10, $text, $white); 

// Output the image
imagejpeg($image_p, null, 80); 

// Free up memory
imagedestroy($image_p);
?>