<?php
require __DIR__ . '/includes/config.php';
try {
    $dbh->query('SELECT 1');
    echo "✅ Connected as " . DB_USER;
} catch (PDOException $e) {
    echo "❌ PDO failed: " . $e->getMessage();
}
