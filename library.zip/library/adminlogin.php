<?php
session_start();
error_reporting(0);
// Explicitly include the correct config.php file
include(__DIR__ . '/includes/config.php');

$errorMsg = '';
if($_SESSION['alogin']!=''){
    $_SESSION['alogin']='';
}
if(isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=md5($_POST['password']);
    $sql ="SELECT UserName,Password FROM admin WHERE UserName=:username and Password=:password";
    $query= $dbh -> prepare($sql);
    $query-> bindParam(':username', $username, PDO::PARAM_STR);
    $query-> bindParam(':password', $password, PDO::PARAM_STR);
    $query-> execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    if($query->rowCount() > 0)
    {
        $_SESSION['alogin']=$_POST['username'];
        echo "<script type='text/javascript'> document.location ='admin/dashboard.php'; </script>";
    } else{
        $errorMsg = 'Invalid Details';
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <!------MENU SECTION START-->
<?php include(__DIR__ . '/includes/header.php');?>
<!-- MENU SECTION END-->
<div class="content-wrapper">
<div class="container">
    <!-- Vibrant Banner -->
    <div class="row">
        <div class="col-md-12">
            <div style="background: linear-gradient(90deg, #43cea2 0%, #185a9d 100%); border-radius: 18px; box-shadow: 0 4px 24px rgba(67,206,162,0.12); margin-bottom: 32px; padding: 32px 0; text-align:center;">
                <span style="color:#185a9d; font-size:2.2em; font-weight:bold; text-shadow:0 2px 12px #43cea2; letter-spacing:2px;">User Login Portal</span>
            </div>
        </div>
    </div>
    <!-- Image Cards Row -->
    <div class="row" style="margin-bottom:32px;">
        <div class="col-md-4">
            <div class="panel panel-info text-center" style="padding:16px;">
                <img src="assets/img/books.jpg" alt="Books" style="width:100%; border-radius:12px; margin-bottom:12px; max-height:120px; object-fit:cover;">
                <h4>Browse Books</h4>
                <p>Discover a world of knowledge at your fingertips.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="panel panel-success text-center" style="padding:16px;">
                <img src="assets/img/students.jpg" alt="Students" style="width:100%; border-radius:12px; margin-bottom:12px; max-height:120px; object-fit:cover;">
                <h4>Student Hub</h4>
                <p>Connect with fellow students and share resources.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="panel panel-warning text-center" style="padding:16px;">
                <img src="assets/img/reading.jpg" alt="Reading" style="width:100%; border-radius:12px; margin-bottom:12px; max-height:120px; object-fit:cover;">
                <h4>Read Anywhere</h4>
                <p>Access your library from any device, anytime.</p>
            </div>
        </div>
    </div>
    <div class="row pad-botm">
        <div class="col-md-12">
            <h4 class="header-line">ADMIN LOGIN FORM</h4>
        </div>
    </div>
             
<!--LOGIN PANEL START-->           
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
<div class="panel panel-info">
<div class="panel-heading">
 LOGIN FORM
</div>
<div class="panel-body">
<?php if($errorMsg) { ?>
    <div class="alert alert-danger text-center"><?php echo htmlentities($errorMsg); ?></div>
<?php } ?>
<form role="form" method="post">
<div class="form-group">
<label>Enter Username</label>
<input class="form-control" type="text" name="username" autocomplete="off" required />
</div>
<div class="form-group">
<label>Password</label>
<input class="form-control" type="password" name="password" autocomplete="off" required />
</div>
 <button type="submit" name="login" class="btn btn-info">LOGIN </button>
</form>
 </div>
</div>
</div>
</div>  
<!---LOGIN PABNEL END-->            
             
 
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
 <?php include(__DIR__ . '/includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
