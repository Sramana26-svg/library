<?php
session_start();
error_reporting(0);
include(__DIR__ . '/includes/config.php');

$errorMsg = '';
if($_SESSION['login']!=''){
    $_SESSION['login']='';
}
if(isset($_POST['login']))
{
    $email=$_POST['emailid'];
    $password=md5($_POST['password']);
    $sql ="SELECT EmailId,Password,StudentId,Status FROM tblstudents WHERE EmailId=:email and Password=:password";
    $query= $dbh -> prepare($sql);
    $query-> bindParam(':email', $email, PDO::PARAM_STR);
    $query-> bindParam(':password', $password, PDO::PARAM_STR);
    $query-> execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    if($query->rowCount() > 0)
    {
        foreach ($results as $result) {
            $_SESSION['stdid']=$result->StudentId;
            if($result->Status==1)
            {
                $_SESSION['login']=$_POST['emailid'];
                echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
            } else {
                $errorMsg = 'Your Account Has been blocked. Please contact admin';
            }
        }
    } else {
        $errorMsg = 'Invalid Details';
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | </title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <!------MENU SECTION START-->
<?php include(__DIR__ . '/includes/header.php');?>
<!-- MENU SECTION END-->
<div class="content-wrapper">
<div class="container">
    <!-- Centered Login Form (original style, no vibrant banner) -->
    <div class="row pad-botm">
        <div class="col-md-12">
            <h4 class="header-line">USER LOGIN FORM</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
            <div class="panel panel-info">
                <div class="panel-heading">
                    LOGIN FORM
                </div>
                <div class="panel-body">
                <?php if($errorMsg) { ?>
                    <div class="alert alert-danger text-center"><?php echo htmlentities($errorMsg); ?></div>
                <?php } ?>
                <form role="form" method="post">
                    <div class="form-group">
                        <label>Enter Email id</label>
                        <input class="form-control" type="text" name="emailid" required autocomplete="off" />
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input class="form-control" type="password" name="password" required autocomplete="off"  />
                        <p class="help-block"><a href="user-forgot-password.php">Forgot Password</a></p>
                    </div>
                    <button type="submit" name="login" class="btn btn-info">LOGIN </button> | <a href="signup.php">Not Register Yet</a>
                </form>
                </div>
            </div>
        </div>
    </div>
    <!---LOGIN PANEL END-->
</div>
</div>
     <!-- CONTENT-WRAPPER SECTION END-->
 <?php include(__DIR__ . '/includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
