<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | User Dash Board</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
            <!-- Vibrant Banner -->
            <div class="row">
                <div class="col-md-12">
                    <div style="background: linear-gradient(90deg, #e0c3fc 0%, #8ec5fc 100%); border-radius: 18px; box-shadow: 0 4px 24px rgba(106,17,203,0.10); margin-bottom: 32px; padding: 32px 0; text-align:center;">
                        <span style="color:#6a11cb; font-size:2.2em; font-weight:bold; text-shadow:0 2px 12px #8ec5fc; letter-spacing:2px;">Welcome to Your Dashboard!</span>
                    </div>
                </div>
            </div>
            <!-- Colorful Dashboard Banner -->
            <div class="row">
                <div class="col-md-12">
                    <div style="background: linear-gradient(90deg, #ffecd2 0%, #fcb69f 100%); border-radius: 18px; box-shadow: 0 4px 24px rgba(252,182,159,0.12); margin-bottom: 32px; overflow: hidden;">
                        <img src="assets/img/dashboard-banner.jpg" alt="Dashboard Banner" style="width:100%; max-height:220px; object-fit:cover; opacity:0.93;">
                        <div style="position:absolute; top:40px; left:0; width:100%; text-align:center; color:#fff; font-size:2em; font-weight:bold; text-shadow:0 2px 12px #fcb69f;">
                            Your Personalized Dashboard
                        </div>
                    </div>
                </div>
            </div>
            <!-- Featured Image -->
            <div class="row" style="margin-bottom:32px;">
                <div class="col-md-12 text-center">
                    <img src="assets/img/books.jpg" alt="Books" style="width:60%; max-width:420px; border-radius:16px; box-shadow:0 2px 16px #e0c3fc; margin-bottom:18px;">
                </div>
            </div>
            <!-- Existing Dashboard Widgets -->
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">ADMIN DASHBOARD</h4>
                </div>
            </div>
             
             <div class="row" style="margin-bottom:32px;">
  <div class="col-md-12">
    <div class="card" style="border-radius:18px; overflow:hidden; box-shadow:0 4px 24px rgba(106,17,203,0.10);">
      <img src="assets/img/dashboard-banner.jpg" alt="Dashboard Banner" class="img-responsive" style="width:100%; max-height:200px; object-fit:cover;">
      <div class="card-body" style="background:linear-gradient(90deg,#e0c3fc 0%,#8ec5fc 100%);">
        <h2 class="text-center" style="color:#6a11cb; font-weight:bold;">Your Library Dashboard</h2>
        <p class="text-center" style="font-size:1.1em; color:#2575fc;">Track your books, returns, and explore new arrivals!</p>
      </div>
    </div>
  </div>
</div>
<div class="row text-center" style="margin-bottom:32px;">
  <div class="col-md-4">
    <img src="assets/img/books.jpg" alt="Books" class="img-responsive" style="width:100%; height:120px; object-fit:cover; border-radius:12px; box-shadow:0 2px 12px #e0c3fc;">
  </div>
  <div class="col-md-4">
    <img src="assets/img/reading.jpg" alt="Reading" class="img-responsive" style="width:100%; height:120px; object-fit:cover; border-radius:12px; box-shadow:0 2px 12px #e0c3fc;">
  </div>
  <div class="col-md-4">
    <img src="assets/img/students.jpg" alt="Students" class="img-responsive" style="width:100%; height:120px; object-fit:cover; border-radius:12px; box-shadow:0 2px 12px #e0c3fc;">
  </div>
</div>

            
                 <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-info back-widget-set text-center">
                            <i class="fa fa-bars fa-5x"></i>
<?php 
$sid=$_SESSION['stdid'];
$sql1 ="SELECT id from tblissuedbookdetails where StudentID=:sid";
$query1 = $dbh -> prepare($sql1);
$query1->bindParam(':sid',$sid,PDO::PARAM_STR);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$issuedbooks=$query1->rowCount();
?>

                            <h3><?php echo htmlentities($issuedbooks);?> </h3>
                            Book Issued
                        </div>
                    </div>
             
               <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-warning back-widget-set text-center">
                            <i class="fa fa-recycle fa-5x"></i>
<?php 
$rsts=0;
$sql2 ="SELECT id from tblissuedbookdetails where StudentID=:sid and RetrunStatus=:rsts";
$query2 = $dbh -> prepare($sql2);
$query2->bindParam(':sid',$sid,PDO::PARAM_STR);
$query2->bindParam(':rsts',$rsts,PDO::PARAM_STR);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$returnedbooks=$query2->rowCount();
?>

                            <h3><?php echo htmlentities($returnedbooks);?></h3>
                          Books Not Returned Yet
                        </div>
                    </div>
        </div>


            
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
<?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
